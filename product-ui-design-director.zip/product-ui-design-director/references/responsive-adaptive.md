# Responsive and Adaptive Rules

Use this file whenever the task spans phone, tablet, and desktop.

## Principle

Treat responsive design as behavior change, not just layout shrinkage. Preserve the same core jobs across devices, but let hierarchy, representation, and interaction model adapt to the available space and input mode.

## Shared Rules

Always:
- Prioritize the primary task for the current device context.
- Preserve orientation cues when panels collapse or move.
- Avoid hover-dependent or precision-only interactions.
- Keep safe tap areas and spacing for touch use.
- Support rotation or resizing without breaking task completion.

## Phone

Design for one-handed, high-interruption use:
- Surface only the highest-value actions by default.
- Convert secondary panes into drill-in screens, bottom sheets, segmented views, or progressive disclosure.
- Rewrite dense tables into record lists, summary rows, or task-driven detail flows when comparison cannot survive.
- Keep forms mostly single-column with labels above fields.
- Place critical actions within ergonomic reach when possible.

## Tablet

Use tablet as a bridge, not a stretched phone:
- Reintroduce split views when they materially improve task flow.
- Preserve generous touch targets even when density increases.
- Allow simultaneous context and detail when the task benefits from it.
- Use tablet to reduce navigation churn in workflows that are cumbersome on phone.

## Desktop

Use larger space to increase context, comparison, and speed:
- Keep navigation stable.
- Show more simultaneous information, not merely larger widgets.
- Use multi-pane layouts for inspection, editing, and monitoring tasks.
- Support expert speed with keyboard shortcuts, command search, and visible batch controls.

## Density Shifts

Tune density by device and job:
- Phone: prioritize essential context and immediate action.
- Tablet: balanced density with visible secondary context.
- Desktop: dense when needed, but structured with stronger grouping and hierarchy.

Do not:
- Keep every module identical across breakpoints.
- Collapse hierarchy so far that users lose context.
- Preserve desktop-only affordances without a touch-safe equivalent.

## Breakpoint Mindset

Do not design to arbitrary widths alone. Decide breakpoints by behavior changes such as:
- When navigation can move from drawer to persistent rail/sidebar.
- When filters can stay visible instead of collapsing.
- When comparison can move from stacked records back to tabular view.
- When detail can live beside a list instead of after it.

## Mobile Accessibility

Account for small screens explicitly:
- Reduce nonessential information per view.
- Keep text, controls, and charts readable without precision zoom.
- Place labels above fields rather than beside them on narrow layouts.
- Preserve clear focus order and screen reader flow.
- Avoid long, disorienting forms or hidden validation.
