# Foundations

Use this file for stable product-UX principles and accessibility floor rules.

## Source Floor

Anchor decisions to:
- WCAG 2.2 AA and mobile accessibility guidance from W3C.
- Established usability heuristics: visibility, real-world language, user control, consistency, error prevention, recognition over recall, expert efficiency, minimalist clarity, recoverable errors, and helpful documentation.
- Current legal/accessibility climate: web and mobile accessibility are active compliance surfaces, not optional polish.

## Core Product Principles

Apply these rules first:
- Keep system status obvious and timely.
- Match product language to the user's domain, not internal implementation terms.
- Make back, cancel, undo, and escape paths easy to find.
- Preserve consistency across patterns, labels, spacing logic, and behavior.
- Prevent mistakes before explaining them.
- Reduce memory load through visible options, previews, defaults, and recent context.
- Support both novice comprehension and expert acceleration.
- Remove visual noise that competes with task-relevant information.
- Write error messages that explain the problem and the recovery path.

## Progressive Disclosure

Use progressive disclosure to reduce clutter without hiding essential power:
- Keep primary task choices visible.
- Hide advanced controls, destructive actions, or infrequent configuration until context makes them relevant.
- Do not bury basic navigation, status, or required form information.
- Prefer revealing complexity by intent, not by surprise.

## Accessibility Floor

Treat these as baseline design constraints:
- Maintain keyboard-operable paths for all core interactions.
- Keep focus indicators obvious and unobscured.
- Size touch targets generously; WCAG 2.2 introduces a 24 by 24 CSS pixel minimum target-size criterion, but practical product UI usually benefits from larger targets for high-frequency actions.
- Preserve sufficient contrast in all states, including placeholders, disabled controls, and charts.
- Provide non-color status cues for errors, selection, and importance.
- Respect reduced-motion preferences and avoid motion that obscures comprehension.
- Associate labels, help text, and errors clearly with their controls.
- Make validation specific, local, and recoverable.

## Feedback and State

Design product feedback at multiple levels:
- Immediate control feedback: hover, press, toggle, selection.
- Transaction feedback: save, sync, import, publish, generate.
- System feedback: loading, background work, stale data, offline, errors.
- Long-running feedback: progress, checkpoints, resumability, notifications.

Prefer reversible flows over warning-heavy flows when possible.

## Dense Interface Discipline

When the surface is complex:
- Use typographic hierarchy before adding decoration.
- Group by job-to-be-done, not by arbitrary card count.
- Let spacing encode relationships.
- Use default states and smart prioritization to reduce visible complexity.
- Preserve scan lines in data-rich surfaces.

## Anti-Patterns

Avoid:
- Decorative minimalism that removes cues users need.
- Abstract marketing language inside operational software.
- Equal visual weight on all modules.
- Placeholder charts or fake metrics used as design filler.
- Overuse of modals for tasks that belong inline or in a side panel.
