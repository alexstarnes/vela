# Agentic UI and AI Patterns

Use this file when the product includes AI generation, automation, assistant behavior, or model-backed decision support.

## Default Stance

Do not bolt a chat box onto every product. Choose the least intrusive AI pattern that helps the user complete the real task.

## Choose the AI Posture

Use one of these patterns deliberately:
- `Ambient`: AI improves ranking, prioritization, autofill, summaries, or defaults with little explicit ceremony.
- `Inline assist`: AI helps inside a field, workflow step, or object view.
- `Supervised automation`: AI drafts or performs actions, but the user reviews scope, output, and consequences before commit.
- `Explicit assistant`: use a chat or composer surface only when open-ended conversation is genuinely the product interaction.

Default decision order:
1. Try `Ambient` first.
2. Use `Inline assist` when the help belongs to a specific object or step.
3. Use `Supervised automation` when the system can act, but trust or consequences require review.
4. Use `Explicit assistant` last, only when the user's job is fundamentally conversational or exploratory.

## Selection Rules

Prefer ambient or inline AI when:
- The user already has a clear workflow.
- The task is object-specific.
- The system can offer concrete assistance without extra conversation.

Prefer explicit chat when:
- Discovery, ideation, or open-ended transformation is the primary job.
- Users need to compare multiple instructions or iterations conversationally.
- The product can ground the conversation in visible context and recoverable output.

## Supervision Rules

Keep humans in control:
- Show what the AI will act on.
- Preview generated or automated output before irreversible steps.
- Expose confidence, uncertainty, or missing data when it matters.
- Preserve undo, retry, edit, and reject paths.
- Attribute suggestions clearly so users can distinguish AI output from system truth or human input.

## Provenance and Trust

Make provenance legible:
- Cite sources, inputs, or affected objects where possible.
- Explain why a recommendation appeared when that affects trust.
- Distinguish inferred data from confirmed data.
- Warn before high-impact automation, publishing, or deletion.

## Interaction Patterns

Use these patterns when appropriate:
- Inline rewrite, summarize, classify, or autofill controls tied to the current object.
- Generated drafts shown in a side-by-side or before/after review.
- Recommendation chips tied to known next actions.
- Batch suggestions with accept/reject and scoped application.
- Activity/history surfaces that show what the system changed.

## Failure Modes

Design these cases intentionally:
- No result or low-confidence result
- Contradictory or stale context
- Partial completion
- Tool or permission failure
- User rejection of the suggestion

Never hide these failures behind vague "something went wrong" copy.

## Anti-Patterns

Avoid:
- AI that interrupts users before they have context.
- Giant empty chat-first home screens for operational software.
- Automation without review paths.
- Ambiguous authorship between AI, system defaults, and human edits.
- Suggestion spam that competes with primary tasks.
