# Visual Language and Craft

Use this file when the work needs to feel distinctive, premium, and product-grade without becoming ornamental.

## Design Character

Build character from disciplined choices:
- Use typography, spacing rhythm, contrast, and motion timing as the primary personality carriers.
- Let the visual system reinforce the product's operating model.
- Keep the interface specific to the product category and audience; avoid interchangeable "SaaS starter" aesthetics.

## Typography

Make type do more work:
- Differentiate display, interface, and data roles clearly.
- Use fewer type styles with stronger intent.
- Preserve readable line lengths and disciplined truncation.
- Use mono or tabular figures where data comparison matters.
- Give dense surfaces sharper hierarchy through weight, size, and spacing instead of decorative containers.

## Color Hierarchy

Use color as a prioritization tool:
- Reserve the most saturated or vivid color for the most meaningful actions and states.
- Use neutrals and quieter tones to support structure.
- Make severity, status, and urgency readable without relying on color alone.
- Keep accent restraint; over-accented software loses hierarchy quickly.

## Composition

Prefer intentional composition over card accumulation:
- Build clear visual zones and edge relationships.
- Use asymmetry when it clarifies hierarchy.
- Let alignment and whitespace create rhythm.
- Use surfaces sparingly; not every section needs its own container.

## Motion

Use motion to clarify structure and consequence:
- Animate entrances, context shifts, and confirmations with purpose.
- Keep timing crisp for operational software.
- Use motion to explain where content came from and where it went.
- Respect reduced motion and avoid theatrical transitions in high-frequency flows.

## Materials and Effects

Use effects only when they improve legibility or hierarchy:
- Blur, translucency, and gradients must support depth or focus.
- Shadows should separate layers, not advertise style.
- Texture and illustration should not compete with operational content.

## Anti-Generic Product UI

Avoid the standard AI-app look:
- Giant central prompt boxes without surrounding workflow context.
- Uniform border radii on every element.
- Flat card grids with equal weight regardless of task importance.
- Low-contrast haze, washed-out text, and decorative gradients used as hierarchy.
- Empty "beautiful" layouts that hide filters, states, or important controls.

Prefer:
- Strong page framing.
- Distinct type roles.
- Crisp state cues.
- Purposeful density.
- Category-specific interaction patterns.

## Taste Test

Before finalizing, ask:
- Would this still be compelling if the gradients disappeared?
- Does the interface look authored, or assembled from defaults?
- Is the visual energy focused where decisions happen?
- Does the surface remain legible when real data and error states appear?
