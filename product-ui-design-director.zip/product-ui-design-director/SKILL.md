---
name: product-ui-design-director
description: Design and review sophisticated software-product UI/UX across web and mobile. Use when creating or critiquing dashboards, app shells, tables, forms, settings, search, multi-pane workflows, AI-assisted features, or other medium-to-high functionality product surfaces that need strong hierarchy, responsive behavior, WCAG 2.2 AA accessibility, and distinctive visual craft instead of generic "AI app" patterns.
---

# Product UI Design Director

## Overview

Design product interfaces with a director's bar for clarity, hierarchy, density, craft, and implementation realism. Treat accessibility and responsiveness as structural requirements, not polish, and reject generic prompt-box-first or card-farm UI unless the product genuinely calls for it.

## Workflow

### 1. Capture Constraints

Infer or collect:
- Primary user jobs, frequency, stakes, and expertise.
- Core surface type: app shell, dashboard, workspace, detail view, settings, onboarding, search, form flow, table-heavy admin UI, or AI-assisted workflow.
- Data density, responsiveness needs, device mix, and trust constraints.
- Brand constraints, platform conventions, and implementation context.

### 2. Load References Selectively

Read only what the task needs:
- `references/foundations.md` for heuristics, progressive disclosure, and accessibility floor.
- `references/complex-product-patterns.md` for app shells, dashboards, forms, tables, and dense workflows.
- `references/responsive-adaptive.md` for phone/tablet/desktop adaptation rules.
- `references/visual-language-and-craft.md` for typography, color, motion, and anti-generic craft.
- `references/agentic-ui-and-ai-patterns.md` when AI is present.
- `references/review-rubric.md` when critiquing or scoring an existing UI.

### 3. Classify the Surface

Choose the operating shape before designing:
- `Shell`: navigation, hierarchy, search, command affordances, persistent utilities.
- `Workspace`: dense tools, side panels, inspectors, states, split panes.
- `Dashboard`: overview, monitoring, drill-down, filters, saved views.
- `Flow`: onboarding, setup, forms, review/confirm, recovery.
- `AI-assisted`: ambient guidance, inline actions, review loops, provenance, undo.

### 4. Choose the Mode

Use one of these output modes explicitly:
- `Concept Mode`: define product direction, character, interaction model, layout system, visual language, and AI posture.
- `Execution Mode`: define screen/spec guidance, states, responsive behavior, accessibility acceptance criteria, and implementation notes.
- `Review Mode`: return findings, anti-patterns, priority fixes, and an elevation plan.

Default mode selection:
- Choose `Execution Mode` for most "design this feature/page/app" requests.
- Choose `Concept Mode` when the user is exploring direction, visual language, or interaction strategy before locking structure.
- Choose `Review Mode` when the user asks for critique, audit, elevation, redesign guidance, or feedback on existing UI.

### 5. Make the Core Decisions

Decide, in this order:
1. Information hierarchy: what must be visible immediately, what is secondary, and what should be progressively disclosed.
2. Navigation model: destination-based, object-based, workflow-based, or command/search-assisted.
3. Density strategy: calm, balanced, or dense; never default to airy if the task is information-rich.
4. Responsive behavior: what reflows, collapses, docks, paginates, stacks, or becomes an alternate representation on phone.
5. State model: empty, loading, optimistic, partial, error, permissions, success, undo, conflict.
6. Accessibility requirements: keyboard path, focus treatment, contrast, touch targets, motion reduction, semantics, validation, recovery.
7. AI posture: absent, ambient, inline assistant, explicit chat, or supervised automation. When AI modality is the design question, compare ambient, inline, supervised, and explicit chat directly, and do not choose explicit chat unless conversation is the clearest fit for the primary job.

### 6. Produce the Output

Use the exact top-level sections for the chosen mode:

For `Concept Mode`:
1. `Design Direction`
2. `Interaction Model`
3. `Layout and Density System`
4. `Visual Language`
5. `Responsive Behavior`
6. `AI Posture`
7. `Risks to Watch`

For `Execution Mode`:
1. `Screen Map`
2. `Core Patterns`
3. `Responsive Rules`
4. `State Matrix`
5. `Accessibility Acceptance Criteria`
6. `Implementation Notes`
7. `Risks to Watch`

For `Review Mode`:
1. `Top Findings`
2. `Scores`
3. `Anti-Patterns`
4. `Priority Fixes`
5. `Elevated Direction`
6. `Responsive and Accessibility Gaps`
7. `Implementation Risks`

## Non-Negotiable Rules

Always:
- Design for the real product job before styling the container.
- Use WCAG 2.2 AA as the minimum floor.
- Make responsiveness structural; do not reduce it to "stack cards on mobile."
- Preserve expert speed without burying novice comprehension.
- Make high-density interfaces legible through hierarchy, grouping, spacing rhythm, and defaults.
- Design all meaningful states, not only the happy path.
- Use motion to clarify change, never to decorate ambiguity.
- Prefer platform-native behaviors when they improve usability.

Do not:
- Default to a giant composer or chat box unless prompting is the primary job to be done.
- Use generic frosted panes, uniform rounded cards, vague gradients, low-contrast fog, or placeholder dashboards as a substitute for hierarchy.
- Shrink desktop tables onto phones without changing representation.
- Hide critical actions behind hover-only, icon-only, or expert-only interactions.
- Treat accessibility as a QA item instead of a design input.

## Complex Product Rules

Apply these defaults unless the task justifies an exception:
- `App shell`: keep primary navigation stable, shallow, and predictable; reserve progressive disclosure for secondary tools, not core wayfinding.
- `Search and command`: add global search or a command layer when object count, navigation depth, or expert usage makes browse-only interaction too slow.
- `Filters`: keep active filters visible, reversible, and easy to audit; expose saved views when workflows repeat.
- `Tables`: use tables for comparison and scanning, not cards. Preserve sort, filter, column control, bulk actions, and drill-down. On phone, switch to an alternate pattern when comparison cannot remain usable.
- `Forms`: prefer one clear primary path, concise labels, helpful defaults, and specific inline recovery. Show required format early, not only after failure.
- `States`: design empty, loading, no-results, error, partial-data, permission-denied, and undo states as first-class surfaces.
- `Trust`: expose provenance, permissions, automation scope, and destructive consequences before the user commits.
- `AI`: keep humans in control with previews, review steps, undo, and confidence cues. Favor ambient and inline assistance over bolted-on chat when the user is already inside a workflow.

## Quality Gate

Before finalizing, confirm all of the following:
- `Hierarchy`: the primary task, state, and next action are clear in two glances.
- `Clarity`: labels, controls, and feedback speak the user's language.
- `Density`: information is neither starved nor cluttered for the job.
- `Responsiveness`: phone, tablet, and desktop each have intentional behavior, not compressed leftovers.
- `Accessibility`: focus, contrast, touch targets, semantics, validation, and reduced motion are covered.
- `Character`: the design has personality through typography, rhythm, color, and interaction, not gimmicks.
- `Implementation realism`: recommendations can be built without magical data, impossible states, or unbounded complexity.

If a prompt asks for "world-class" or "premium" UI, raise the craft bar while preserving product legibility and task speed.
