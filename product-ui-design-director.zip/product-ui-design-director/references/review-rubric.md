# Review Rubric

Use this file when critiquing an existing interface or proposed direction.

## Scoring Dimensions

Score each dimension from 1 to 5 and explain the reason briefly:
- `Clarity`: Can users understand the current state, primary task, and next action quickly?
- `Hierarchy`: Is visual and interaction emphasis allocated by importance?
- `Task flow`: Does the workflow reduce friction, memory load, and unnecessary context switching?
- `Responsiveness`: Does behavior adapt intentionally across phone, tablet, and desktop?
- `Accessibility`: Are contrast, focus, touch targets, semantics, validation, and recovery covered?
- `Density discipline`: Is the information level right for the job?
- `Distinctiveness`: Does the UI feel authored and category-specific rather than generic?
- `Implementation readiness`: Are the ideas concrete enough to build without invention?

## Review Output Format

Return:
1. `Top Findings`
2. `Scores`
3. `Priority Fixes`
4. `Elevated Direction`
5. `Risks to Watch`

## Severity Guide

Use this language consistently:
- `Critical`: blocks task completion, trust, or accessibility.
- `High`: materially hurts comprehension, speed, or quality.
- `Medium`: creates friction or genericness that weakens the product.
- `Low`: polish issue or secondary optimization.

## Review Prompts

Look for these specific issues:
- Is the surface too airy for the functional demand?
- Are important actions visually buried?
- Are filters, scope, or state changes too easy to miss?
- Does mobile behavior preserve the same job, or merely compress the desktop?
- Does the AI affordance belong in the flow, or has chat been used as a shortcut?
- Does the design rely on cards and blur instead of hierarchy and composition?
- Are error, empty, and loading states underdesigned?

## Elevation Rules

When proposing fixes:
- Improve structure before adding style.
- Replace generic containers with clearer layout and type hierarchy.
- Raise contrast and state clarity before adding ornament.
- Make the responsive model explicit.
- Preserve what already works; do not recommend novelty for its own sake.
