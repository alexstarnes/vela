# Complex Product Patterns

Use this file when the task involves medium-to-high functionality software.

## App Shells

Design shells as stable orientation systems:
- Keep primary navigation consistent across the product.
- Separate global navigation from local object navigation.
- Keep utilities such as profile, notifications, help, and workspace switching distinct from task navigation.
- Use breadcrumbs, tabs, segmented controls, or secondary sidebars only when they express different levels of hierarchy.

Use command/search support when:
- The object space is large.
- Users repeat expert workflows.
- Navigation depth would otherwise slow retrieval.

## Dashboards

Use dashboards to orient, monitor, and route action:
- Lead with the most consequential signals and pending decisions.
- Pair summaries with drill-down paths.
- Keep metric context visible: timeframe, comparison basis, filters, freshness.
- Make alerts actionable, not merely decorative.
- Avoid equal-sized cards for everything; rank modules by operational importance.

## Dense Workspaces

Use dense layouts for creation, review, operations, or analysis tools:
- Separate canvas/content, controls, metadata, and history into clear zones.
- Use side panels and inspectors for secondary detail rather than modals.
- Keep current selection, mode, and unsaved state obvious.
- Let panels collapse, resize, or dock without losing wayfinding.

## Filters and Views

Make filtering audit-friendly:
- Show active filters as visible tokens or a summary bar.
- Expose clear reset behavior.
- Distinguish temporary refinements from saved views.
- Preserve sort order and scope visibly.
- Show result counts when they materially affect user confidence.

## Tables

Use tables when comparison, scanning, or bulk action is central:
- Keep columns purposeful and named in user language.
- Support sorting, filtering, row selection, and drill-in.
- Use sticky headers or columns when scan context would otherwise be lost.
- Provide density options only if they do not destabilize readability.
- On narrow screens, change the representation: prioritized fields, expandable rows, split views, or task-specific record lists.

Do not:
- Turn comparison tasks into disconnected cards.
- Hide bulk actions until too late in the workflow.
- Force horizontal scrolling for critical comprehension on phone unless there is no viable alternative.

## Forms and Setup Flows

Prefer form flows that feel guided rather than bureaucratic:
- Use one primary path and clear secondary actions.
- Keep labels persistent; do not rely on placeholder-as-label.
- Group related inputs and show rationale when asking for sensitive or complex information.
- Use inline validation for format and impossible states; reserve summary error regions for multi-error recovery.
- Break long setup into meaningful sections with progress and review.

## Detail Views

Design detail views as decision surfaces:
- Lead with object identity, status, and next actions.
- Keep related data, activity, and configuration grouped by intent.
- Make edit boundaries clear: inline edit, side sheet, dedicated edit mode, or separate flow.
- Show provenance, ownership, and permission implications when they matter.

## States

Define these explicitly for any serious product surface:
- First-run empty
- Empty after filters
- Loading and background refresh
- Partial data and degraded mode
- Error and recovery
- Permission denied
- Success and undo
- Destructive confirmation

## Trust and Safety

Elevate trust when users can publish, send, delete, automate, or share:
- Preview outputs before commit.
- Explain scope and impact before destructive actions.
- Preserve auditability for high-stakes changes.
- Make recovery paths visible, especially undo, versioning, or history.
